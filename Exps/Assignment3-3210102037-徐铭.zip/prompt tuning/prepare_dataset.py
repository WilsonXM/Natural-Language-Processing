import math
import random
import csv


def read_and_label(file_path, label):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    labeled_data = [{'text': line.strip(), 'label': label} for line in lines]
    return labeled_data


# 读取文件并打上标签
negative_data = read_and_label('./data/rt-polarity.neg', 'negative')
positive_data = read_and_label('./data/rt-polarity.pos', 'positive')

# 合并数据
all_data = negative_data + positive_data

# 打乱数据
random.shuffle(all_data)

# 转化为字典
data_dict = {
    'text': [item['text'] for item in all_data],
    'label': [item['label'] for item in all_data]
}


# 打印字典中前五行的数据
def print_first_five(data_dict):
    for i in range(5):
        print(f"Text: {data_dict['text'][i]}, \
            Label: {data_dict['label'][i]}\n")


print_first_five(data_dict)

# 设置训练集和测试集的比例
split_ratio = 0.8
split_index = math.floor(len(data_dict['text']) * split_ratio)

# 拆分字典数据为训练和测试部分
train_data_dict = {key: value[:split_index] for key, value in data_dict.items()}
test_data_dict = {key: value[split_index:] for key, value in data_dict.items()}

# 写入训练数据到 CSV 文件
with open('train.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=data_dict.keys())
    writer.writeheader()
    for i in range(len(train_data_dict['text'])):
        row = {key: train_data_dict[key][i] for key in train_data_dict.keys()}
        writer.writerow(row)

# 写入测试数据到 CSV 文件
with open('test.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=data_dict.keys())
    writer.writeheader()
    for i in range(len(test_data_dict['text'])):
        row = {key: test_data_dict[key][i] for key in test_data_dict.keys()}
        writer.writerow(row)
